#!/bin/bash
echo "Idea from https://www.if-not-true-then-false.com"
sudo -s
sudo chmod +x ./nvidia-driver-installer-part-1.sh
sudo chmod +x ./nvidia-driver-installer-part-2.sh
sudo chmod +x ./nvidia-driver-installer-part-3.sh
sudo chmod +x ./nvidia-driver-installer-part-4.sh
sudo chmod +x ./nvidia-driver-uninstaller.sh
sudo sudo bash ./nvidia-driver-installer-part-1.sh
